//
//  RepeatoRender.h
//  RepeatoRender
//
//  Created by John Holdsworth on 10/05/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for RepeatoRender.
FOUNDATION_EXPORT double RepeatoRenderVersionNumber;

//! Project version string for RepeatoRender.
FOUNDATION_EXPORT const unsigned char RepeatoRenderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RepeatoRender/PublicHeader.h>

@interface RepeatoRender: NSObject
+ (void)startCapture:(NSString *)addrs;
@end
