//
//  RepeatoRender.h
//  RepeatoRender

#import <Foundation/Foundation.h>
#import <arpa/inet.h>

//! Project version number for RepeatoRender.
FOUNDATION_EXPORT double RepeatoRenderVersionNumber;

//! Project version string for RepeatoRender.
FOUNDATION_EXPORT const unsigned char RepeatoRenderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RepeatoRender/PublicHeader.h>

// Various wire formats supported.
typedef NS_ENUM(int, RMFormat) {
    MINICAP_VERSION = 1, // https://github.com/openstf/minicap#usage
    HYBRID_VERSION = 2, // minicap but starting with "Remote" header
    REMOTE_NOKEY = 3, // Original format
    REMOTE_VERSION = 4 // Sends source file path for security check
};

@interface RepeatoRender: NSObject
+ (void)startCapture:(NSString *)addrs;
+ (void)setFormat:(RMFormat)format port:(in_port_t)port
          retries:(int)retries sleep:(NSTimeInterval)sleep;
+ (void)setDefer:(NSTimeInterval)defer maxDefer:(NSTimeInterval)maxDefer
     jpegQuality:(double)jpegQuality benchmark:(BOOL)benchmark;
+ (void)shutdown;
@end
